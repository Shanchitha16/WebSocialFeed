let feedData = [
    { username: "alice", text: "Just started learning HTML!", timestamp: "2 mins ago" },
    { username: "bob", text: "JavaScript is amazing!", timestamp: "5 mins ago" },
    { username: "carol", text: "Python makes web dev easier.", timestamp: "10 mins ago" },
    { username: "dave", text: "I love open source projects.", timestamp: "15 mins ago" },
    { username: "eve", text: "Building a mini Twitter clone!", timestamp: "20 mins ago" },
    { username: "frank", text: "Time to debug some code.", timestamp: "25 mins ago" },
    { username: "grace", text: "Responsive UI is important.", timestamp: "30 mins ago" }
];

let displayed = 0;
const postsPerLoad = 3;

function loadMore() {
    const feed = document.getElementById("feed");
    for (let i = displayed; i < displayed + postsPerLoad && i < feedData.length; i++) {
        const post = document.createElement("div");
        post.className = "post";
        post.innerHTML = `<div class='username'>@${feedData[i].username}</div>
                          <div class='text'>${feedData[i].text}</div>
                          <div class='timestamp'>${feedData[i].timestamp}</div>`;
        feed.appendChild(post);
    }
    displayed += postsPerLoad;
}
window.onload = loadMore;